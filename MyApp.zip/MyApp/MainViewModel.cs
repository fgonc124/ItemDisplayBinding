﻿using CommunityToolkit.Mvvm.ComponentModel; // If using CommunityToolkit.Mvvm
//using MyApp.Models;
using System.Collections.ObjectModel;
using static Android.Provider.Contacts;

namespace MyApp.ViewModels
{
    public partial class MainViewModel : ObservableObject
    {
        [ObservableProperty]
        private ObservableCollection<Person> people;

        [ObservableProperty]
        private Person selectedPerson;

        public MainViewModel()
        {
            People = new ObservableCollection<Person>
            {
                new Person { Name = "Alice", Age = 30, City = "New York" },
                new Person { Name = "Bob", Age = 25, City = "London" },
                new Person { Name = "Charlie", Age = 35, City = "Paris" }
            };

            SelectedPerson = People[0]; // Set a default selected item
        }
    }
}