using CommunityToolkit.Maui.Markup; // Essential for fluent markup
using Microsoft.Maui.Controls;
//using MyApp.Models; // Your data model
using MyApp.ViewModels;
using System.ComponentModel.DataAnnotations; // Your view model
using CommunityToolkit.Maui.Markup; // Don't forget this using statement!
using Microsoft.Maui.Controls;
using Microsoft.Maui;

namespace MyApp.Views
{
    public class NewPage1 : ContentPage
    {
        public NewPage1(MainViewModel viewModel)
        {
            BindingContext = viewModel;

            Content = new VerticalStackLayout
            {
                Children =
                {
                    new Label()
                        .Text("Select a person:")
                        .FontSize(20)
                        .CenterHorizontal()
                        .Margins(0, 20, 0, 10),

                    new Picker()
                        //.Title("Choose a Person")
                        .Bind(Picker.ItemsSourceProperty, static (MainViewModel vm) => vm.People) // Bind ItemsSource to your collection
                        // Fluent ItemDisplayBinding using a lambda expression:
                        .ItemDisplayBinding(Binding.Create<Person, string>(static (item) => item.Name)) // THIS IS THE KEY!
//                        Binding.Create(static (Monkey monkey) => monkey.Name)
                        // You can also bind SelectedItem
                        //.Bind(Picker.SelectedItemProperty, static (MainViewModel vm) => vm.SelectedPerson,
                        //      mode: BindingMode.TwoWay)
                        .Margin(10),

                    new Label()
                        .Bind(Label.TextProperty, static (MainViewModel vm) => vm.SelectedPerson,
                              convert: (Person p) => p != null ? $"Selected: {p.Name} ({p.Age} from {p.City})" : "No person selected")
                        .FontSize(18)
                        .CenterHorizontal()
                        .Margins(0, 20, 0, 0)
                }
            }
            .Spacing(10)
            .Padding(20);
        }
    }
}